var urlJSON = "/acme/js/acme.json"

// Function Calls:
buildNav();


// Function Definitions:
function buildNav()
{
	let navContent;

	// Build home button
	navContent = "<ul class=\"navUL\"><li><button onclick=\"navigate(home.id)\">Home</button></li>";
	console.log(navContent);

	// Build Anvils, Explosives, Decoys and Traps from JSON
	// fetch JSON
	fetch(urlJSON) 
	.then(function(response){
	  if(response.ok){ 
	   return response.json(); 
	  } 
	  throw new ERROR('Response not OK.');
	})
	.then(function (data) { //store fetched data as object 'data'
	  // Let's see what we got back
	  console.log('Json object from buildNav function:'); 
	  console.log(data);		//display fetched data
	  //console.log("Test: data.[0]: " + data[1]); 	// debug

	  for (x in data)  			// use loop to populate nav bar
	  {
		navContent += "<li><button onclick=\"navigate(" + data[x].linkName.toLowerCase() + ".id)\">" + data[x].linkName + "</button></li>";
		console.log("Loop output: " + data[x].linkName.toLowerCase());
	  }
	
	  navContent += "</ul>";	// close the list
	  document.getElementById("nav").innerHTML = navContent;
	  
	  console.log("buildNav has set navContent to: " + navContent); // debug

	 }) 
	.catch(error => console.log('There was a buildNav() error: ', error)) 
	}


function navigate(input)
{
	console.log("navigate() has received: " + input);
	
	// Replace class of all articles with 'hide'. Use classList.add("class"); to add a class
	document.getElementById("home").setAttribute("class", "hide");
	document.getElementById("anvils").setAttribute("class", "hide");
	document.getElementById("explosives").setAttribute("class", "hide");
	document.getElementById("decoys").setAttribute("class", "hide");
	document.getElementById("traps").setAttribute("class", "hide");

	// console.log("log: " + input);
	document.getElementById(input).setAttribute("class", "show");

}